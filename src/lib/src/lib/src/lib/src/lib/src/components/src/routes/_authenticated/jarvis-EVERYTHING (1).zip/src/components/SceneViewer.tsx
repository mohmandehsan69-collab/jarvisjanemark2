import { useEffect, useRef, useState } from "react";
import type { Scene3D, ScenePart } from "@/lib/scene3d.server";

/** Three.js is pulled from a CDN at runtime so the project needs no extra
 *  dependency install. Cached by the browser after the first load. */
const THREE_URL = "https://esm.sh/three@0.160.0";

type Props = {
  scene: Scene3D | null;
  className?: string;
  /** Wireframe outlines on every part — makes massing far easier to read. */
  edges?: boolean;
  autoRotate?: boolean;
  /** Set by the viewer so the page can offer a GLB download. */
  onReady?: (api: { exportGlb: () => Promise<Blob | null> }) => void;
};

export function SceneViewer({ scene, className, edges = true, autoRotate = false, onReady }: Props) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const sceneRef = useRef<any>(null);
  const threeRef = useRef<any>(null);
  const groupRef = useRef<any>(null);
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");
  const [message, setMessage] = useState("");

  // One-time engine setup: renderer, camera, lights, ground, orbit controls.
  useEffect(() => {
    let disposed = false;
    let raf = 0;
    let renderer: any;
    let onResize: (() => void) | null = null;

    (async () => {
      try {
        const THREE = await import(/* @vite-ignore */ THREE_URL);
        if (disposed) return;
        threeRef.current = THREE;
        const mount = mountRef.current;
        if (!mount) return;

        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0x07070a);
        scene.fog = new THREE.Fog(0x07070a, 120, 600);

        const camera = new THREE.PerspectiveCamera(
          45,
          mount.clientWidth / Math.max(mount.clientHeight, 1),
          0.1,
          5000,
        );
        camera.position.set(28, 20, 34);

        renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
        renderer.setSize(mount.clientWidth, mount.clientHeight);
        renderer.shadowMap.enabled = true;
        renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        // Without these, standard materials render flat and washed out.
        renderer.outputColorSpace = THREE.SRGBColorSpace;
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1.05;
        mount.appendChild(renderer.domElement);

        scene.add(new THREE.HemisphereLight(0xffffff, 0x2a2a35, 1.1));
        const key = new THREE.DirectionalLight(0xffd9a8, 2.1);
        key.position.set(40, 60, 30);
        key.castShadow = true;
        key.shadow.mapSize.set(1024, 1024);
        key.shadow.camera.near = 1;
        key.shadow.camera.far = 4000;
        scene.add(key);
        scene.add(key.target);
        const fill = new THREE.DirectionalLight(0x88aaff, 0.5);
        fill.position.set(-30, 25, -20);
        scene.add(fill);

        const ground = new THREE.Mesh(
          new THREE.PlaneGeometry(2000, 2000),
          new THREE.MeshStandardMaterial({ color: 0x14141c, roughness: 1, metalness: 0 }),
        );
        ground.rotation.x = -Math.PI / 2;
        ground.receiveShadow = true;
        scene.add(ground);

        const grid = new THREE.GridHelper(400, 80, 0xff6b1a, 0x2a2a33);
        (grid.material as any).opacity = 0.22;
        (grid.material as any).transparent = true;
        scene.add(grid);

        const group = new THREE.Group();
        scene.add(group);
        groupRef.current = group;
        sceneRef.current = { scene, camera, renderer };

        // Minimal orbit controls — avoids a second CDN import for OrbitControls.
        let dragging = false;
        let px = 0;
        let py = 0;
        let theta = Math.atan2(camera.position.x, camera.position.z);
        let phi = Math.acos(camera.position.y / camera.position.length());
        let radius = camera.position.length();
        const target = new THREE.Vector3(0, 4, 0);

        const applyCamera = () => {
          phi = Math.max(0.12, Math.min(Math.PI / 2 - 0.02, phi));
          camera.position.set(
            target.x + radius * Math.sin(phi) * Math.sin(theta),
            target.y + radius * Math.cos(phi),
            target.z + radius * Math.sin(phi) * Math.cos(theta),
          );
          camera.lookAt(target);
        };
        applyCamera();

        const el = renderer.domElement as HTMLCanvasElement;
        el.style.touchAction = "none";
        el.addEventListener("pointerdown", (e: PointerEvent) => {
          dragging = true;
          px = e.clientX;
          py = e.clientY;
          el.setPointerCapture(e.pointerId);
        });
        el.addEventListener("pointermove", (e: PointerEvent) => {
          if (!dragging) return;
          theta -= (e.clientX - px) * 0.006;
          phi -= (e.clientY - py) * 0.006;
          px = e.clientX;
          py = e.clientY;
          applyCamera();
        });
        el.addEventListener("pointerup", () => (dragging = false));
        el.addEventListener("pointercancel", () => (dragging = false));
        el.addEventListener(
          "wheel",
          (e: WheelEvent) => {
            e.preventDefault();
            radius = Math.max(3, Math.min(1200, radius * (1 + Math.sign(e.deltaY) * 0.12)));
            applyCamera();
          },
          { passive: false },
        );

        // Frame using the real bounding box of the built geometry rather than a
        // guessed radius, so odd-shaped or off-centre models still fill the view.
        sceneRef.current.frameBox = (box: any) => {
          if (!box || box.isEmpty()) return;
          const size = box.getSize(new THREE.Vector3());
          const centre = box.getCenter(new THREE.Vector3());
          const extent = Math.max(size.x, size.y, size.z, 1);
          const fitDistance = extent / (2 * Math.tan((camera.fov * Math.PI) / 360));
          radius = Math.max(4, fitDistance * 1.75);
          target.copy(centre);
          camera.near = Math.max(0.05, radius / 500);
          camera.far = radius * 40;
          camera.updateProjectionMatrix();

          // Keep the sun tight around the model or shadows vanish on big scenes.
          const s = extent * 0.85;
          key.shadow.camera.left = -s;
          key.shadow.camera.right = s;
          key.shadow.camera.top = s;
          key.shadow.camera.bottom = -s;
          key.position.set(centre.x + extent, centre.y + extent * 1.4, centre.z + extent * 0.8);
          key.target.position.copy(centre);
          key.target.updateMatrixWorld();
          key.shadow.camera.updateProjectionMatrix();

          grid.position.set(centre.x, 0, centre.z);
          applyCamera();
        };
        sceneRef.current.setAutoRotate = (on: boolean) => {
          sceneRef.current.autoRotate = on;
        };

        onResize = () => {
          if (!mount.clientWidth) return;
          camera.aspect = mount.clientWidth / Math.max(mount.clientHeight, 1);
          camera.updateProjectionMatrix();
          renderer.setSize(mount.clientWidth, mount.clientHeight);
        };
        window.addEventListener("resize", onResize);

        const tick = () => {
          if (sceneRef.current?.autoRotate && !dragging) {
            theta += 0.0022;
            applyCamera();
          }
          renderer.render(scene, camera);
          raf = requestAnimationFrame(tick);
        };
        tick();
        setStatus("ready");

        onReady?.({
          exportGlb: async () => {
            try {
              const mod = await import(
                /* @vite-ignore */ "https://esm.sh/three@0.160.0/examples/jsm/exporters/GLTFExporter.js"
              );
              const exporter = new mod.GLTFExporter();
              const target = groupRef.current;
              if (!target) return null;
              const buffer: ArrayBuffer = await new Promise((resolve, reject) =>
                exporter.parse(target, resolve, reject, { binary: true }),
              );
              return new Blob([buffer], { type: "model/gltf-binary" });
            } catch {
              return null;
            }
          },
        });
      } catch (err) {
        setStatus("error");
        setMessage(err instanceof Error ? err.message : "Could not load the 3D engine.");
      }
    })();

    return () => {
      disposed = true;
      cancelAnimationFrame(raf);
      if (onResize) window.removeEventListener("resize", onResize);
      try {
        renderer?.dispose?.();
        renderer?.domElement?.remove();
      } catch {
        /* noop */
      }
    };
  }, []);

  // Rebuild the mesh group whenever a new scene arrives.
  useEffect(() => {
    const THREE = threeRef.current;
    const group = groupRef.current;
    if (!THREE || !group || !scene) return;

    while (group.children.length) {
      const child = group.children.pop();
      child.geometry?.dispose?.();
      child.material?.dispose?.();
    }

    const geometryFor = (part: ScenePart) => {
      const [a, b, c] = part.size;
      const taper = part.taper ?? 1;
      switch (part.type) {
        case "cylinder":
          return new THREE.CylinderGeometry(a * taper, a, b, 32);
        case "cone":
          return new THREE.ConeGeometry(a, b, 32);
        case "sphere":
          return new THREE.SphereGeometry(a, 32, 24);
        case "torus":
          return new THREE.TorusGeometry(a, b, 16, 48);
        case "plane":
          return new THREE.PlaneGeometry(a, c);
        case "pyramid":
          // 4-sided cone, rotated so a face points forward rather than a corner.
          return new THREE.ConeGeometry(a * Math.SQRT2, b, 4).rotateY(Math.PI / 4);
        case "prism": {
          // 3-sided cylinder laid on its side = a gabled roof running along z.
          const g = new THREE.CylinderGeometry(a, a, c, 3);
          g.rotateX(Math.PI / 2);
          g.rotateZ(Math.PI / 2);
          g.scale(1, b / a, 1);
          return g;
        }
        default:
          return new THREE.BoxGeometry(a, b, c);
      }
    };

    const bounds = new THREE.Box3();
    for (const part of scene.parts) {
      const geometry = geometryFor(part);
      const colour = new THREE.Color(part.color ?? "#9aa3ad");
      const glow = part.emissive ?? 0;
      const material = new THREE.MeshStandardMaterial({
        color: colour,
        transparent: (part.opacity ?? 1) < 1,
        opacity: part.opacity ?? 1,
        metalness: part.metalness ?? 0.1,
        roughness: part.roughness ?? 0.75,
        emissive: glow > 0 ? colour.clone() : new THREE.Color(0x000000),
        emissiveIntensity: glow,
      });
      const count = part.repeat?.count ?? 1;
      const offset = part.repeat?.offset ?? [0, 0, 0];
      const mesh = new THREE.InstancedMesh(geometry, material, count);
      mesh.castShadow = true;
      mesh.receiveShadow = true;

      const dummy = new THREE.Object3D();
      const [rx, ry, rz] = part.rotation ?? [0, 0, 0];
      for (let i = 0; i < count; i++) {
        dummy.position.set(
          part.position[0] + offset[0] * i,
          part.position[1] + offset[1] * i,
          part.position[2] + offset[2] * i,
        );
        dummy.rotation.set(
          (rx * Math.PI) / 180,
          (ry * Math.PI) / 180,
          (rz * Math.PI) / 180,
        );
        if (part.type === "plane") dummy.rotation.x -= Math.PI / 2;
        dummy.updateMatrix();
        mesh.setMatrixAt(i, dummy.matrix);
        // Accumulate true world bounds so framing is exact.
        const half = new THREE.Vector3(part.size[0], part.size[1], part.size[2]);
        bounds.expandByPoint(dummy.position.clone().sub(half));
        bounds.expandByPoint(dummy.position.clone().add(half));
      }
      mesh.instanceMatrix.needsUpdate = true;
      group.add(mesh);

      // Outlines: architectural massing reads far better with visible edges.
      if (edges && count <= 60 && part.type !== "sphere" && part.type !== "torus") {
        const outline = new THREE.LineSegments(
          new THREE.EdgesGeometry(geometry, 25),
          new THREE.LineBasicMaterial({
            color: 0x000000,
            transparent: true,
            opacity: 0.22,
          }),
        );
        const holder = new THREE.Group();
        for (let i = 0; i < count; i++) {
          const clone = outline.clone();
          clone.position.set(
            part.position[0] + offset[0] * i,
            part.position[1] + offset[1] * i,
            part.position[2] + offset[2] * i,
          );
          clone.rotation.set((rx * Math.PI) / 180, (ry * Math.PI) / 180, (rz * Math.PI) / 180);
          if (part.type === "plane") clone.rotation.x -= Math.PI / 2;
          holder.add(clone);
        }
        group.add(holder);
      }
    }

    sceneRef.current?.frameBox?.(bounds);
  }, [scene, edges]);

  useEffect(() => {
    sceneRef.current?.setAutoRotate?.(autoRotate);
  }, [autoRotate]);

  return (
    <div className={className ?? "relative size-full"}>
      <div ref={mountRef} className="size-full" />
      {status !== "ready" ? (
        <div className="absolute inset-0 flex items-center justify-center bg-[#07070a] text-sm text-white/60">
          {status === "loading" ? "Loading 3D engine…" : message}
        </div>
      ) : null}
      {status === "ready" && !scene ? (
        <div className="pointer-events-none absolute inset-x-0 bottom-4 text-center text-xs text-white/40">
          Drag to orbit · scroll to zoom
        </div>
      ) : null}
    </div>
  );
}
