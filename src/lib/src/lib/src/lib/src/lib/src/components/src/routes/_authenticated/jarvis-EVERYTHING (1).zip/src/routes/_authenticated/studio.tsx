import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Box, Download, Grid3x3, Loader2, Maximize2, Minimize2, RotateCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Page } from "@/components/app/Page";
import { SceneViewer } from "@/components/SceneViewer";
import { buildScene } from "@/lib/scene3d.functions";
import type { Scene3D } from "@/lib/scene3d.server";

const title = "3D studio — build models from a description";
const description =
  "Describe a building or an object and Jarvis composes it from geometric primitives, rendered live in the browser.";

export const Route = createFileRoute("/_authenticated/studio")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: StudioPage,
});

const EXAMPLES = [
  "A 12-storey office tower with a glass curtain wall and a stone base",
  "A traditional Afghan compound house with a walled courtyard",
  "A wooden dining chair",
  "A two-stage rocket on a launch pad",
];

function StudioPage() {
  const build = useServerFn(buildScene);
  const [prompt, setPrompt] = useState("");
  const [scene, setScene] = useState<Scene3D | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [full, setFull] = useState(false);
  const [edges, setEdges] = useState(true);
  const [spin, setSpin] = useState(false);
  const [api, setApi] = useState<{ exportGlb: () => Promise<Blob | null> } | null>(null);

  const download = async () => {
    const blob = await api?.exportGlb();
    if (!blob) {
      setError("Export failed — the 3D engine could not package this scene.");
      return;
    }
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${(scene?.name ?? "model").replace(/[^a-z0-9]+/gi, "-").toLowerCase()}.glb`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const run = async (text: string, refine: boolean) => {
    const value = text.trim();
    if (!value || busy) return;
    setBusy(true);
    setError(null);
    try {
      const result = await build({
        data: { prompt: value, previous: refine ? scene : undefined },
      });
      setScene(result as Scene3D);
      setPrompt("");
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  };

  const viewer = (
    <SceneViewer
      scene={scene}
      edges={edges}
      autoRotate={spin}
      onReady={setApi}
      className={
        full ? "absolute inset-0 size-full" : "relative h-[460px] w-full overflow-hidden rounded-xl"
      }
    />
  );

  const controls = (
    <div className="flex flex-wrap gap-2">
      <Button size="sm" variant={edges ? "default" : "outline"} onClick={() => setEdges((v) => !v)}>
        <Grid3x3 className="mr-2 size-3.5" /> Edges
      </Button>
      <Button size="sm" variant={spin ? "default" : "outline"} onClick={() => setSpin((v) => !v)}>
        <RotateCw className="mr-2 size-3.5" /> Spin
      </Button>
      <Button size="sm" variant="outline" onClick={() => void download()} disabled={!scene}>
        <Download className="mr-2 size-3.5" /> .glb
      </Button>
    </div>
  );

  if (full) {
    return (
      <div className="fixed inset-0 z-50 bg-[#07070a]">
        {viewer}
        <div className="absolute right-5 top-5 z-10 flex gap-2">
          {controls}
          <Button size="sm" variant="outline" onClick={() => setFull(false)}>
            <Minimize2 className="mr-2 size-3.5" /> Exit
          </Button>
        </div>
        {scene ? (
          <p className="pointer-events-none absolute inset-x-0 bottom-5 text-center text-sm text-white/70">
            {scene.name} · {scene.parts.length} parts
          </p>
        ) : null}
      </div>
    );
  }

  return (
    <Page eyebrow="3D" title="Studio" intro={description}>
      <div className="panel space-y-4 p-5">
        <div className="flex flex-col gap-2 sm:flex-row">
          <Input
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") void run(prompt, Boolean(scene));
            }}
            placeholder={scene ? "Change it — e.g. add two more floors" : "Describe a building or object…"}
            disabled={busy}
          />
          <div className="flex gap-2">
            <Button onClick={() => void run(prompt, false)} disabled={busy || !prompt.trim()}>
              {busy ? <Loader2 className="mr-2 size-4 animate-spin" /> : <Box className="mr-2 size-4" />}
              Build new
            </Button>
            {scene ? (
              <Button
                variant="outline"
                onClick={() => void run(prompt, true)}
                disabled={busy || !prompt.trim()}
              >
                Refine
              </Button>
            ) : null}
          </div>
        </div>

        {!scene && !busy ? (
          <div className="flex flex-wrap gap-2">
            {EXAMPLES.map((example) => (
              <button
                key={example}
                type="button"
                onClick={() => void run(example, false)}
                className="rounded-full border border-border px-3 py-1 text-xs text-muted-foreground transition hover:text-foreground"
              >
                {example}
              </button>
            ))}
          </div>
        ) : null}

        {controls}

        {error ? <p className="text-sm leading-relaxed text-destructive">{error}</p> : null}
      </div>

      <div className="panel relative mt-4 overflow-hidden p-0">
        {viewer}
        <Button
          size="sm"
          variant="outline"
          onClick={() => setFull(true)}
          className="absolute right-4 top-4 z-10"
        >
          <Maximize2 className="mr-2 size-3.5" /> Fullscreen
        </Button>
      </div>

      {scene ? (
        <div className="panel mt-4 space-y-1 p-5">
          <p className="label-mono">{scene.name}</p>
          <p className="text-sm leading-relaxed text-muted-foreground">{scene.description}</p>
          <p className="text-xs text-muted-foreground">
            {scene.parts.length} primitives · drag to orbit, scroll to zoom
          </p>
        </div>
      ) : null}
    </Page>
  );
}
